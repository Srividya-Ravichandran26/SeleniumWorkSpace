package pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class MyLeadsPage extends ProjectSpecificMethods{
	
	public MyLeadsPage(ChromeDriver driver, Properties prop) {
		this.driver = driver;
		this.prop = prop;
	}
	
	public CreateLeadPage clickCreateLead() {
		driver.findElement(By.linkText(prop.getProperty("MyLeadsPage.createLeadLink.linkText"))).click();
		
		return new CreateLeadPage(driver, prop);
	}
	
	public FindPage clickFindLead() {
		driver.findElement(By.linkText("Find Leads")).click();
		
		return new FindPage(driver, prop);
	}
	
	public MergePage clickMergeButton() {
		driver.findElement(By.linkText("Merge Leads")).click();// Merge Leads
		return new MergePage(driver, prop);
	}
}


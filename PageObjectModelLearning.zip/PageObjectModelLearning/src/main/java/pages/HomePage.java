package pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods{

	public HomePage(ChromeDriver driver, Properties prop) {
		this.driver = driver;
		this.prop = prop;
	}
	
	public MyHomepage clickCrmLink() {
		driver.findElement(By.linkText(prop.getProperty("HomePage.CrmsfaLink.linkText"))).click();
		
		return new MyHomepage(driver, prop);
	}
	
	public LoginPage clickLogout() {
		
		driver.findElement(By.className("decorativeSubmit")).click();
		return new LoginPage(driver, prop);
	}
}

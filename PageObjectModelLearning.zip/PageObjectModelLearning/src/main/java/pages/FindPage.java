package pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

import base.ProjectSpecificMethods;

public class FindPage extends ProjectSpecificMethods{
	public static String linkValue;
	
	public FindPage(ChromeDriver driver, Properties prop) {
		this.driver = driver;
		this.prop = prop;
	}
	
	public FindPage getAndEnterFirstName() throws Exception {
		String firstName = driver.findElement(By.xpath("//div[@class='x-grid3-body']//tr[1]/td[contains(@class,'td-firstName')]//a")).getText();
		driver.findElement(By.xpath("//div[@class='x-tab-panel']//input[@name='firstName']")).sendKeys(firstName);
		Thread.sleep(2000);
		return this;
	}
	
	public FindPage clickPhoneTab() throws Exception {
		driver.findElement(By.xpath("//span[@class='x-tab-strip-inner']/span[text()='Phone']")).click();
		Thread.sleep(1000);
		return this;
	}
	
	public FindPage clickEmailTab() throws Exception {
		driver.findElement(By.xpath("//span[@class='x-tab-strip-inner']/span[text()='Email']")).click();
		Thread.sleep(2000);
		
		return this;

	}
	
	public FindPage enterLeadID() throws Exception {
		driver.findElement(By.xpath("//div[@class='x-tab-panel']//input[@name='id']")).sendKeys(linkValue);
		Thread.sleep(2000);
		return this;
	}
		
	public FindPage clickFindLeadsButton() throws Exception {
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(2000);
		return this;
	}
	
	public FindPage getAndEnterPhoneNumber() throws Exception {
//		String number = driver.findElement(By.xpath("//div[@class='x-grid3-body']/div[7]//tr[1]//td[contains(@class,'x-grid3-td-formatedPrimaryPhone')]//div")).getText().substring(9, 11);
		driver.findElement(By.xpath("//div[@class='x-tab-panel']//input[@name='phoneNumber']")).sendKeys("90");
		Thread.sleep(2000);
		return this;
	}
	
	public ViewLeadPage clickThirdData() {
		linkValue = driver.findElement(By.xpath("//div[@class='x-grid3-body']/div[3]//tr[1]/td[1]")).getText();
		driver.findElement(By.linkText(linkValue)).click();
		
		return new ViewLeadPage(driver, prop);
	}
	
	public FindPage verifyNoRecords() {
		String noRecordText = driver.findElement(By.xpath("//div[text()='No records to display']")).getText();			
		new SoftAssert().assertEquals(noRecordText, "No records to display");
		return this;
	}
		
}

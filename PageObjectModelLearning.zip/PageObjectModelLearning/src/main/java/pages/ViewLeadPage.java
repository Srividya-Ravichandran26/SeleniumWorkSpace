package pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

import base.ProjectSpecificMethods;

public class ViewLeadPage extends ProjectSpecificMethods{

	public ViewLeadPage(ChromeDriver driver, Properties prop) {
		this.driver = driver;
		this.prop = prop;
	}
	
	public ViewLeadPage verifyFirstName(String expectedName) {
		String firstName = driver.findElement(By.id(prop.getProperty("ViewLead.firstName.id"))).getText();
		new SoftAssert().assertEquals(firstName, expectedName);		
		return this;
	}
	
	public EditPage clickEdit() {
		driver.findElement(By.linkText("Edit")).click();
		return new EditPage(driver, prop);
	}
	
	public MyLeadsPage clickDelete() {
		driver.findElement(By.linkText("Delete")).click();
		return new MyLeadsPage(driver, prop);
	}
	
	public DuplicateLeadPage clickDuplicateLeadButton() {
		driver.findElement(By.linkText("Duplicate Lead")).click();
		return new DuplicateLeadPage(driver, prop);
	}
	
	public ViewLeadPage verifyCompanyName(String expectedCompanyName) {
		String actualCompanyName = driver.findElement(By.id("viewLead_companyName_sp")).getText().replaceAll("[^a-zA-Z]+", "");
		new SoftAssert().assertEquals(actualCompanyName, expectedCompanyName);		
		return this;
	}
}

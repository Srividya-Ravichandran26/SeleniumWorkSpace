package pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class EditPage extends ProjectSpecificMethods{

	public EditPage(ChromeDriver driver, Properties prop) {
		this.driver = driver;
		this.prop = prop;
	}
	
	public EditPage changeCompanyName(String companyName) {
		driver.findElement(By.id("updateLeadForm_companyName")).clear();
		driver.findElement(By.id("updateLeadForm_companyName")).sendKeys(companyName);
		return this;
	}
	
	public ViewLeadPage clickUpdate() {
		driver.findElement(By.xpath("//input[@value='Update']")).click();
		return new ViewLeadPage(driver, prop);
	}
	
}

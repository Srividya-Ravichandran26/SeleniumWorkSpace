package pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class CreateLeadPage extends ProjectSpecificMethods{

	public CreateLeadPage(ChromeDriver driver, Properties prop) {
		this.driver = driver;
		this.prop = prop;
	}
	public CreateLeadPage enterCompanyName(String companyName) {
		driver.findElement(By.id(prop.getProperty("CreateLead.companyName.id"))).sendKeys(companyName); // company name
		return this;
	}
	
	public CreateLeadPage enterFirstName(String firstName) {
		driver.findElement(By.id(prop.getProperty("CreateLead.firstName.id"))).sendKeys(firstName); // first name
		return this;
	}
	
	public CreateLeadPage enterLastName(String LastName) {
		driver.findElement(By.id(prop.getProperty("CreateLead.lastName.id"))).sendKeys(LastName);// last name
		return this;
	}
	
	public ViewLeadPage clickCreateLeadButton() {
		driver.findElement(By.name(prop.getProperty("CreateLead.createLeadButton.name"))).click();// click create lead button
		return new ViewLeadPage(driver, prop);
	}
	
	
}

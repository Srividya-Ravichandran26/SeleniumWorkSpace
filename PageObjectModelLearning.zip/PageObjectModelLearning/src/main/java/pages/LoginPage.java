package pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods{

	public LoginPage(ChromeDriver driver, Properties prop) {
		this.driver = driver;
		this.prop = prop;
	}
	
	public LoginPage enterUsername() {
		
		driver.findElement(By.id(prop.getProperty("LoginPage.Username.id"))).sendKeys(prop.getProperty("username"));
		
		return this;
	}
	
	public LoginPage enterPassword() {
		driver.findElement(By.id(prop.getProperty("LoginPage.Password.id"))).sendKeys(prop.getProperty("password"));	
		
		return this;
	}
	
	public HomePage clickLogin() {
		
		driver.findElement(By.className(prop.getProperty("LoginPage.LoginButton.class"))).click();
		
		return new HomePage(driver, prop);
	}
}

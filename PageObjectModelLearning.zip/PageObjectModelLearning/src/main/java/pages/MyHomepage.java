package pages;

import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class MyHomepage extends ProjectSpecificMethods{
	
	public MyHomepage(ChromeDriver driver, Properties prop) {
		this.driver = driver;
		this.prop = prop;
	}
	
	public MyLeadsPage clickLeadsLink() {
		driver.findElementByLinkText(prop.getProperty("MyHomepage.leadsLink.linkText")).click();
		
		return new MyLeadsPage(driver, prop);
	}

}

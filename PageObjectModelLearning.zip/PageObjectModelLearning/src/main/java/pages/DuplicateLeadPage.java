package pages;

import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

import base.ProjectSpecificMethods;

public class DuplicateLeadPage extends ProjectSpecificMethods{

	public DuplicateLeadPage(ChromeDriver driver, Properties prop) {
		this.driver = driver;
		this.prop = prop;
	}
	
	public CreateLeadPage verifyTitle(String expectedTitle) {
		new SoftAssert().assertEquals(driver.getTitle(), expectedTitle);
		return new CreateLeadPage(driver, prop);
	}
}

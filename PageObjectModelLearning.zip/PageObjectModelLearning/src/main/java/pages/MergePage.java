package pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class MergePage extends ProjectSpecificMethods{

	public MergePage(ChromeDriver driver, Properties prop) {
		this.driver = driver;
		this.prop = prop;
	}
	
	public MergeSearchPopUpPage clickFromLeadSearchIcon() {
		driver.findElement(By.xpath("//img[@src='/images/fieldlookup.gif']")).click();// Click From lead icon
		return new MergeSearchPopUpPage(driver, prop);
	}
	
	public MergeSearchPopUpPage clickToLeadSearchIcon() {
		driver.findElement(By.xpath("(//img[@src='/images/fieldlookup.gif'])[2]")).click();// Click To lead icon
		return new MergeSearchPopUpPage(driver, prop);

	}
}

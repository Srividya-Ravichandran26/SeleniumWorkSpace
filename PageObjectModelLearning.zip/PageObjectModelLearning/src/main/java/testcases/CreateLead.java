package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class CreateLead extends ProjectSpecificMethods {

	@BeforeTest
	public void setFileName() {
		excelFileName = "createLead";
	}
	
	@Test(dataProvider = "FetchData")
	public void runCreateLead(String companyName, String firstName, String lastName) {
		new LoginPage(driver, prop).enterUsername().enterPassword().clickLogin().clickCrmLink().clickLeadsLink().clickCreateLead()
				.enterCompanyName(companyName).enterFirstName(firstName).enterLastName(lastName).clickCreateLeadButton().verifyFirstName(firstName);
	}
}

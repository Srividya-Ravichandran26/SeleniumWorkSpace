package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class EditLead extends ProjectSpecificMethods {

	@BeforeTest
	public void setFileName() {
		excelFileName = "EditLead";
	}

	@Test(dataProvider = "FetchData")
	public void runEditLeads(String companyName) throws Exception {
		new LoginPage(driver, prop).enterUsername().enterPassword().clickLogin().clickCrmLink()
				.clickLeadsLink().clickFindLead().getAndEnterFirstName().clickFindLeadsButton().clickThirdData().clickEdit().changeCompanyName(companyName)
				.clickUpdate().verifyCompanyName(companyName);
	}
}

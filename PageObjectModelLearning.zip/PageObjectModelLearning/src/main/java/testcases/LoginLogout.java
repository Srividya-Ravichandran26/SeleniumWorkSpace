package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class LoginLogout extends ProjectSpecificMethods{
	
		
	@Test
	public void runLoginLogout() {
		new LoginPage(driver, prop).enterUsername().enterPassword().clickLogin().clickLogout();

	}

}

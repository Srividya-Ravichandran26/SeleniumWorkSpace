package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.FindPage;
import pages.LoginPage;

public class DuplicateLead extends ProjectSpecificMethods{

	@Test
	public void runDuplicateLead() throws Exception, Exception {
		new LoginPage(driver, prop).enterUsername().enterPassword().clickLogin().clickCrmLink()
				.clickLeadsLink().clickFindLead().clickEmailTab().clickFindLeadsButton().clickThirdData().clickDuplicateLeadButton()
				.verifyTitle("Duplicate Lead | opentaps CRM").clickCreateLeadButton().verifyFirstName(new FindPage(driver, prop).linkValue);
	}
}
